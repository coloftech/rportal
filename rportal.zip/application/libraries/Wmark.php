<?php

/**
* 
*/

require_once APPPATH.'third_party/PHPWatermark/Watermark.php';
class Wmark extends Watermark
{
	
}